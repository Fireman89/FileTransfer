from mysql.connector import MySQLConnection, Error
from python_mysql_dbconfig import read_db_config

def update_item(id, title):
	db_config = read_db_config()
	
	query = """ UPDATE books
				set title = %s
				WHERE id = %s """
				
	data = (title, id)
	
	try:
		conn = MySQLConnection(**db_config)
		
		#update a field
		cursor = conn.cursor()
		cursor.execute(query, data)
		
		#accept the changes
		conn.commit()
		
	except Error as error:
		print(error)
		
	finally:
		cursor.close()
		conn.close()
		
if __name__ == '__main__':
	update_item(37, 'A NEW TITLE THAT WAS CHANGED')
