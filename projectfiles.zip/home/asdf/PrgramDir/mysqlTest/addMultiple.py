from mysql.connector import MySQLConnection, Error
from python_mysql_dbconfig import read_db_config

def insert_multiple_items(items):
	query = "INSERT INTO books(title, isbn)" \
			"VALUES(%s,%s)"
	try:
		db_config = read_db_config()
		conn = MySQLConnection(**db_config)
		
		cursor = conn.cursor()
		cursor.executemany(query, items)
		
		conn.commit()
	except Error as e:
		print('Error:', e)
		
	finally:
		cursor.close()
		conn.close()
		
def main():
	items = [('titan', '1'), 
			 ('hunter', '2'),
			 ('warlock', '3')]
	insert_multiple_items(items)
	
if __name__ == '__main__':
	main()
