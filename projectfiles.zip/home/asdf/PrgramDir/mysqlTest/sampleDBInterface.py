from mysql.connector import MySQLConnection, Error
from python_mysql_dbconfig import read_db_config
from addItem import insert_item
from addMultiple import insert_multiple_items
from updateItem import update_item
from deleteItem import delete_item
from fetchOne import query_with_fetchone
from fetchMany import query_with_fetchmany
from fetchAll import query_with_fetchall

def create():
	print ("you want to create a thing\n")
	
def read():
	print ("you want to read a thing\n")

def update():
	print ("you want to update a thing\n")
	
def delete():
	print ("you want to delet a thing\n")
	
def exit():
	print("Exiting the client page")

def main():
	userInput = None
	
	print("enter a thing into the console")
	
	while userInput != 'quit':
		userInput = input("enter a command: ")
		if userInput == 'create':
			create()
		elif userInput == 'read':
			read()
		elif userInput == 'update':
			update()
		elif userInput == 'delete':
			delete()
		elif userInput == 'quit':
			exit()
		else:
			print ("invalid instruction")
		
	
if __name__ == '__main__':
	main()
